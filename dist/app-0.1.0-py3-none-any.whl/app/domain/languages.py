from enum import Enum

class Language(Enum):
    SP = "SP"
    EN = "EN"