from enum import Enum

class PokerRoom(Enum):
    STARS = "STARS"
    WINAMAX = "WINAMAX"
