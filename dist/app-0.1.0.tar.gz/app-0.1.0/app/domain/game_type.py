from enum import Enum

class GameType(Enum):
    ZOOM = "zoom"
    REGULAR = "regular"
    MTT = "mtt"
    SNG = "sng"